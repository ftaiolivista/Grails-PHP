package com.caucho.quercus.lib.resin;

public class MBeanServer {
}
