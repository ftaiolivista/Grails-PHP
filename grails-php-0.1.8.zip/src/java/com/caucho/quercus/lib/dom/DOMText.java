package com.caucho.quercus.lib.dom;

public class DOMText {
}
